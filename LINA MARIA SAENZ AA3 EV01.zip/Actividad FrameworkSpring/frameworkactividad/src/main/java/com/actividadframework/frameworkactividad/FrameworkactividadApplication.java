package com.actividadframework.frameworkactividad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.actividadframework.frameworkactividad.controllers.InformacionFW;

@RestController
@SpringBootApplication
public class FrameworkactividadApplication {

	public static void main(String[] args) {
		SpringApplication.run(FrameworkactividadApplication.class, args);
	}

	@GetMapping("/PruebaFramework")

	public InformacionFW messageView(){

	return new InformacionFW(LocalDateTime.now(),"Lina", "Saenz", "2675774");

	}

}
