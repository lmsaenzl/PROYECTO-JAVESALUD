package com.actividadframework.frameworkactividad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FrameworkactividadApplicationTests {

	@Test
	void contextLoads() {
	}

}
